package com.cloudwebrtc.webrtc.record;

public enum AudioChannel {
    INPUT,
    OUTPUT
}