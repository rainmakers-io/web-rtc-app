package com.cloudwebrtc.webrtc.utils;

public interface Callback {

    void invoke(Object... args);
}
