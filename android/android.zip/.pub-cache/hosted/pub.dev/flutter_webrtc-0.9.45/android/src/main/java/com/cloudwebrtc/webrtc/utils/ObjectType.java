package com.cloudwebrtc.webrtc.utils;

public enum ObjectType {
    Null,
    Boolean,
    Number,
    String,
    Map,
    Array,
    Byte
}
