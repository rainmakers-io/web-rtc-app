package com.example.web_rtc_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
